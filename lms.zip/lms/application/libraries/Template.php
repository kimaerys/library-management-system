<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Template
{
	var $ci;

	function __construct() 
	{
		$this->ci =& get_instance();
	}

	function load($tpl_view, $body_view = null, $data = null)
	{
		// Check if body view is supplied
		if ( ! is_null( $body_view ) )
		{
			// Several checks are made to ensure if the file exists or not
			// Show error if file is not found
			if ( file_exists( APPPATH.'views/'.$tpl_view.'/'.$body_view ) )
				$body_view_path = $tpl_view.'/'.$body_view;
			elseif ( file_exists( APPPATH.'views/'.$tpl_view.'/'.$body_view.'.php' ) )
				$body_view_path = $tpl_view.'/'.$body_view.'.php';
			elseif ( file_exists( APPPATH.'views/'.$body_view ) )
				$body_view_path = $body_view;
			elseif ( file_exists( APPPATH.'views/'.$body_view.'.php' ) )
				$body_view_path = $body_view.'.php';
			else
				show_error('Unable to load the requested file: ' . $tpl_view.'/'.$body_view.'.php');

			$body = $this->ci->load->view($body_view_path, $data, TRUE);

			// Check if there is data or what type of data
			if ( is_null($data) )
				$data = array('body' => $body);
			else if ( is_array($data) )
				$data['body'] = $body;
			else if ( is_object($data) )
				$data->body = $body;
		}

		// Load template view file from the application/views/template
		$this->ci->load->view('templates/'.$tpl_view, $data);
	}
}