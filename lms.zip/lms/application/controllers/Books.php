<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Books extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{
		parent::__construct();

		$this->load->model('mBooks');
	}

	public function index()
	{
		$data = array(
			'title' => 'Library Management System',
			'nav'	=> $this->load->view('templates/nav',null,true),
			'main'	=> $this->load->view('books/index',null,true)
		);
		
		$this->template->load('default', null, $data);
	}

	public function readAll()
	{
		$output = null;
		$output = $this->mBooks->readAllBooks();
		$response = array(
			'aaData'				=> $output,
			'iTotalRecords'			=> count($output),
			'iTotalDisplayRecords'	=> count($output),
			'iDisplayStart'			=> 0,
		);

		if( isset($_REQUEST['sEcho']) )
			$response['sEcho'] 	= $_REQUEST['sEcho'];

		header("Content-Type: application/json", true);
		echo json_encode($response);
	}

	public function searchBy()
	{
		$category	= !empty($this->uri->segment(3)) ? $this->uri->segment(3) : null;
		$keyword 	= !empty($this->uri->segment(4)) ? $this->uri->segment(4) : null;
		$output = null;
		
		$output = $this->mBooks->searchBooksBy( $category, $keyword );
		
		$response = array(
			'aaData'				=> $output,
			'iTotalRecords'			=> count($output),
			'iTotalDisplayRecords'	=> count($output),
			'iDisplayStart'			=> 0,
		);

		if( isset($_REQUEST['sEcho']) )
			$response['sEcho'] 	= $_REQUEST['sEcho'];

		header("Content-Type: application/json", true);
		echo json_encode($response);
	}

	public function ifBookExists()
	{
		$response = null;

		if ( ! empty($this->input->post('ID')) )
		{
			$data = array(
				'ID'	=> $this->input->post('ID'),
				'Title'	=> $this->input->post('title'),
				'Author'=> $this->input->post('author'),
			);
		}
		else
		{
			$data = array(
				'ID'	=> null,
				'Title'	=> $this->input->post('title'),
				'Author'=> $this->input->post('author'),
			);
		}

		if( $this->mBooks->ifBookExists($data) )
			$response = "The book your trying to add already exists.";
		else
			$response = "true";

		header("Content-Type: application/json");
		$this->output->set_output(print(json_encode($response)));
		exit();
	}

	public function add()
	{
		$output = null;
		if( ! is_null( $this->input->post() ) )
		{
			$data = array(
				'Title'		=> $this->input->post('title'),
				'Author'	=> $this->input->post('author'),
				'Genre'		=> $this->input->post('genre'),
				'Section'	=> $this->input->post('section'),
				'Status'	=> 'Available'
			);

			$output = $this->mBooks->add($data);
		}
		else
		{
			$output = "Error";
		}

		header("Content-Type: application/json", true);
		echo json_encode($output);
	}

	public function getSelected()
	{
		$response = null;
		$response = $this->mBooks->getSelected( $this->input->post('ID') );

		header("Content-Type: application/json", true);
		$this->output->set_output(print(json_encode($response)));
		exit();
	}

	public function update()
	{
		$output = null;
		if( ! empty( $this->input->post('ID') ) )
		{
			$data = array(
				'ID'		=> $this->input->post('ID'),
				'Title'		=> $this->input->post('title'),
				'Author'	=> $this->input->post('author'),
				'Genre'		=> $this->input->post('genre'),
				'Section'	=> $this->input->post('section')
			);

			$output = $this->mBooks->update($data);
		}
		else
		{
			$output = "Error";
		}

		header("Content-Type: application/json", true);
		echo json_encode($output);
	}

	public function lend()
	{
		$response = null;
		$response = $this->mBooks->lend( $this->input->post('ID') );

		header("Content-Type: application/json", true);
		$this->output->set_output(print(json_encode($response)));
		exit();
	}

	public function delete()
	{
		$response = null;
		$response = $this->mBooks->delete( $this->input->post('ID') );

		header("Content-Type: application/json", true);
		$this->output->set_output(print(json_encode($response)));
		exit();
	}

	public function borrow()
	{
		$data = array(
			'title' => 'Library Management System',
			'nav'	=> $this->load->view('templates/nav',null,true),
			'main'	=> $this->load->view('books/borrow',null,true)
		);
		
		$this->template->load('default', null, $data);
	}

	public function readAllBorrowed()
	{
		$output = null;
		$output = $this->mBooks->readAllBorrowedBooks();
		$response = array(
			'aaData'				=> $output,
			'iTotalRecords'			=> count($output),
			'iTotalDisplayRecords'	=> count($output),
			'iDisplayStart'			=> 0,
		);

		if( isset($_REQUEST['sEcho']) )
			$response['sEcho'] 	= $_REQUEST['sEcho'];

		header("Content-Type: application/json", true);
		echo json_encode($response);
	}

	public function returnBook()
	{
		$response = null;
		$response = $this->mBooks->returnBook( $this->input->post('ID') );

		header("Content-Type: application/json", true);
		$this->output->set_output(print(json_encode($response)));
		exit();
	}
}
