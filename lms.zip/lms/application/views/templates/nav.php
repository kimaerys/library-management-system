	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container"> <a class="brand" href="<?=site_url();?>">Library Management System  </a>
			</div>
			<!-- /container -->
		</div>
		<!-- /navbar-inner -->
	</div>
	<div class="subnavbar">
		<div class="subnavbar-inner">
			<div class="container">
				<ul class="mainnav">
					<li <?php if($this->uri->segment(2) != "borrow") echo  'class="active"'; ?>><a href="<?= site_url('books')?>"><i class="icon-book"></i><span>Available Books</span> </a> </li>
				</ul>
			</div>
			<!-- /container -->
		</div>
		<!-- /subnavbar-inner -->
	</div>
	<!-- /subnavbar -->