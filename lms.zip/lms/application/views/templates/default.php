<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="apple-mobile-web-app-capable" content="yes">
	<title><?php echo $title; ?></title>
	<!-- Bootstrap -->
	<link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">
	<link href="<?php echo base_url('assets/bootstrap/css/bootstrap-responsive.min.css');?>" rel="stylesheet">
	<!-- Styles -->
	<link href="<?php echo base_url('assets/bootstrap/css/style.css');?>" rel="stylesheet">
	<!-- DataTables -->
	<link href="<?php echo base_url('assets/datatables/dataTables.bootstrap.css');?>" rel="stylesheet">
	<!-- Toastr style -->
	<link href="<?php echo base_url('assets/toastr/toastr.min.css');?>" rel="stylesheet">
	<!-- Font -->
	<link href="<?php echo base_url('assets/bootstrap/css/font-awesome.css')?>" rel="stylesheet">
	<link href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600" rel="stylesheet">
	<!-- jQuery 2.2.3 -->
	<script src="<?php echo base_url('assets/bootstrap/js/jquery-1.7.2.min.js');?>"></script>

	
	<!-- <link href="css/pages/dashboard.css" rel="stylesheet"> -->
	<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>

<body>
	<?php echo $nav; ?>

	<?php echo $main; ?>

	<!-- Bootstrap JS -->
	<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.js');?>"></script>
	<!-- DataTables -->
	<script src="<?php echo base_url('assets/datatables/jquery.dataTables.min.js');?>"></script>
	<script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.min.js');?>"></script>
	<!-- Toastr script -->
	<script src="<?php echo base_url('assets/toastr/toastr.min.js');?>"></script>
	<!-- JQuery Validation -->
	<script src="<?php echo base_url('assets/validate/jquery.validate.min.js');?>"></script>
</body>

</html>