	<div class="main">
		<div class="main-inner">
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="widget" id="searchForm">
							<div class="widget-header"> <i class="icon-search"></i>
								<h3> Find a Book</h3>
								<div class="widget-tools pull-right">
									<button class="btn btn-default" data-toggle="tooltip" data-placement="top" title="Show search/filter box" id="btnSearchBook"><i class="icon-chevron-down"></i></button>
								</div>
							</div>
							<!-- /widget-header -->
							<div class="widget-content hidden">
								<div class="row">
									<div class="span8" style="padding-right: 50px; padding-left: 8-px;">
										<form id="filterForm" method="post" class="form-horizontal">
											<fieldset>
												<div class="control-group">
													<label class="control-label">Search by<span class="required">*</span></label>
													<div class="controls">
														<select class="form-control span6" name="category" required="required">
															<option value="Title">Title</option>
															<option value="Author">Author</option>
															<option value="Section">Library Section</option>
														</select>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Keyword <span class="required">*</span></label>
													<div class="controls">
														<input type="text" class="form-control span6" required name="keyword"/>
													</div>
												</div>
												<div class="pull-right">
													<button type="submit" id="searchBook" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Save" >Search</button>
													<button type="button" id="btnCancelSearch" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Cancel" >Cancel</button>
												</div>
											</fieldset>
										</form>
									</div>
								</div>
								<div class="row">
									<div class="span11" style="padding-right: 50px; padding-left: 30px">
										<table class="table table-striped table-hover table-bordered" id="result" cellspacing="0" width="100%">
											<thead>
												<tr>
													<th><center>Title</center></th>
													<th><center>Author</center></th>
													<th><center>Genre</center></th>
													<th><center>Library Section</center></th>
												</tr>
											</thead>
											<tbody>

											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /widget -->
				</div>
				<!-- /row -->
				<div class="row">
					<div class="span12">
						<div class="widget" id="booksForm">
							<div class="widget-header"> <i class="icon-list-alt"></i>
								<h3> Books Form</h3>
							</div>
							<!-- /widget-header -->
							<div class="widget-content hidden">
								<div class="row">
									<div class="span8" style="padding-right: 50px; padding-left: 50px">
										<form id="submitForm" method="post" class="form-horizontal" action="#">
											<fieldset>
												<div class="control-group" style="padding-left: 50px">
													<h4>Fill in the details below. Fields with<span class="required"> * </span>are required</h4>
												</div>
												<div class="control-group hidden">
													<label class="control-label">ID <span class="required">*</span></label>
													<div class="controls">
														<input type="hidden" class="form-control span6" required name="ID" id="ID"/>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Title <span class="required">*</span></label>
													<div class="controls">
														<input type="text" class="form-control span6" required name="title"/>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Author <span class="required">*</span></label>
													<div class="controls">
														<input type="text" class="form-control span6" required name="author"/>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Genre <span class="required">*</span></label>
													<div class="controls">
														<select class="form-control span6" name="genre" required="required">
															<option value="Horror">Horror</option>
															<option value="Romance">Romance</option>
															<option value="Thriller">Thriller</option>
															<option value="Novel">Novel</option>
															<option value="Fantasy">Fantasy</option>
															<option value="Mystery">History</option>
														</select>
													</div>
												</div>
												<div class="control-group">
													<label class="control-label">Library Section <span class="required">*</span></label>
													<div class="controls">
														<select class="form-control span6" name="section"  required="required">
															<option value="Circulation">Circulation</option>
															<option value="PeriodicalSection">Periodical Section</option>
															<option value="GeneralReference">General Reference</option>
															<option value="Fiction">Fiction</option>
															<option value="ChildrenSection">Children's Section</option>
														</select>
													</div>
												</div>
												<div class="pull-right">
													<button type="submit" id="saveBook" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Save" >Save</button>
													<button type="button" id="btnCancel" class="btn btn-danger" data-toggle="tooltip" data-placement="top" title="Cancel" >Cancel</button>
												</div>
											</fieldset>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /widget -->
				</div>
				<!-- /row -->
				<div class="row">
					<div class="span12">
						<div class="widget" id="booksTable">
							<div class="widget-header"> <i class="icon-table"></i>
								<h3> Books List</h3>
								<div class="widget-tools pull-right">
									<button class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Add a new book" id="btnNewBook"><i class="icon-plus"></i>&nbsp;Add New Book</button>
								</div>
							</div>
							<!-- /widget-header -->
							<div class="widget-content">
								<div class="row">
									<div class="span12">
										<table class="table table-striped table-hover table-bordered" id="table" cellspacing="0" width="100%">
											<thead>
												<tr>
													<th><center>Title</center></th>
													<th><center>Author</center></th>
													<th><center>Genre</center></th>
													<th><center>Library Section</center></th>
													<th><center>Status</center></th>
													<th><center>Action</center></th>
												</tr>
											</thead>
											<tbody>

											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /widget -->
				</div>
				<!-- /row -->

				<!-- Loading Modal -->
				<div id="loadingModal" class="modal fade" role="dialog">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<center>
								<div id="message">
									<div class='alert alert-info'><img src='<?php echo base_url('assets/img/loading.gif');?>'/> Heads up! </strong>Please wait while we process your request...</div>
								</div>
							</center>
						</div>
						<!-- /.modal-content -->
					</div>
					<!-- /.modal-dialog -->
				</div>
				<!-- /Loading Modal -->
			</div>
			<!-- /container -->
		</div>
		<!-- /main-inner --> 
	</div>
	<!-- /main -->

	<script type="text/javascript">
		$(document).ready(function(){
			loadTable();

			$('#btnNewBook').click(function(){
				$('#submitForm').show();
				$('#booksForm>.widget-content').slideDown(400).removeClass('hidden');
				clearForm();
				scrollToForm();
			});

			$('#btnCancel').click(function(){
				$('#booksForm>.widget-content').slideUp();
				setTimeout(function() {
					$('#submitForm').hide();
					clearForm();
				}, 400);
				scrollToTable();
			});

			$('#btnSearchBook').click(function(){
				if($('#filterForm').is(':hidden')){
					$('#filterForm').show();
					$('#searchForm>.widget-content').slideDown(400).removeClass('hidden');
					$('#btnSearchBook>i').removeClass('icon-chevron-down').addClass('icon-chevron-up');

					$('#result').dataTable().fnClearTable();
					$('#result').dataTable().fnDraw();
					$('#result').dataTable().fnDestroy();

					$('#result').DataTable({
						'deferLoading'	: 10,
						'ordering'		: false,
						'dom'			: '<"top"fl>rt<"bottom"ip><"clear">',
						"language"		: {
							"emptyTable": "<center>No exisisting books.</center>"
						}
					});

					$('.dataTables_filter input').addClass('form-control').attr('placeholder','Search...');
					$('.dataTables_length select').addClass('form-control');
				}else{
					$('#searchForm>.widget-content').slideUp();
					setTimeout(function() {
						$('#filterForm').hide();
					}, 400);
					$('#btnSearchBook>i').removeClass('icon-chevron-up').addClass('icon-chevron-down');
				}
			});

			$('#btnCancelSearch').click(function(){
				$('#searchForm>.widget-content').slideUp();
				setTimeout(function() {
					$('#filterForm').hide();
					$('input[name=keyword]').val('');
				}, 400);
				$('#btnSearchBook>i').removeClass('icon-chevron-up').addClass('icon-chevron-down');
			});

			$('#submitForm').validate({
				debug: true,
				rules:{
					title:{
						required: true,
						remote: {
							url: "<?php echo site_url('Books/ifBookExists');?>",
							type: "post",
							data: {
								title: function(){
									return $('input[name=title]').val();
								},
								author: function(){
									return $('input[name=author]').val();
								},
								ID: function(){
									if($('input[name=ID]').val() != "")
										return $('input[name=ID]').val();
									else
										return "";
								}
							}
						}
					},
					author: {
						required: true,
						remote: {
							url: "<?php echo site_url('Books/ifBookExists');?>",
							type: "post",
							data: {
								title: function(){
									return $('input[name=title]').val();
								},
								author: function(){
									return $('input[name=author]').val();
								},
								ID: function(){
									if($('input[name=ID]').val() != "")
										return $('input[name=ID]').val();
									else
										return "";
								}
							}
						}
					},
					genre : "required",
					section: "required"
				},
				messages:{
				},
				errorElement: "em",
				errorPlacement: function ( error, element ) {
					// Add the `help-block` class to the error element
					error.addClass( "help-block" );

					if ( element.prop( "type" ) === "checkbox" ) {
						error.insertAfter( element.parent( "label" ) );
					} else {
						error.insertAfter( element );
					}
				},
				highlight: function ( element, errorClass, validClass ) {
					$( element ).parents( ".control-group" ).addClass( "has-error" ).removeClass( "has-success" );
				},
				unhighlight: function (element, errorClass, validClass) {
					$( element ).parents( ".control-group" ).addClass( "has-success" ).removeClass( "has-error" );
				},
				submitHandler: function(form){
					if ($('#ID').val() == ""){
						var url = "<?php echo site_url('books/add'); ?>";
						var act = "added";
					}
					else{
						var url = "<?php echo site_url('books/update'); ?>"
						var act = "updated";
					}
					
					setTimeout(function()
					{
						$.ajax({	
							type:"POST",
							async: true,
							url:url,
							data:new FormData(form),
							dataType: 'json',
							cache: false,
							contentType: false,
							processData:false,
							beforeSend: function() 
							{
								$('#loadingModal').modal({
									toggle: "true",
									backdrop: "static",
									keyboard: "false"
								});
							},
							success: function(data)
							{
								if (data == "Success"){
									toastr.options = {
										closeButton: true,
										progressBar: true,
										showMethod: 'slideDown',
										timeOut: 3000
									};
									toastr.success('A book has been successfully '+act+'.','Success');
									$('#booksForm>.widget-content').slideUp();
									clearForm();							
									loadTable();
									scrollToTable();
								}else{
									toastr.options = {
										closeButton: true,
										progressBar: true,
										showMethod: 'slideDown',
										timeOut: 3000
									};
									toastr.warning(data, 'The book was not '+act+'.');
								}
							},
							error: function(data)
							{
								toastr.options = {
									closeButton: true,
									progressBar: true,
									showMethod: 'slideDown',
									timeOut: 3000
								};
								toastr.error('Please check your inputs. If you are sure that you didn\'t caused the problem, please reload the page and try again.', 'We encountered a problem!');
							},
							complete: function()
							{
								$('#loadingModal').modal('toggle');
							}
						})
					}, 1500)
				}
			});

			$('#filterForm').validate({
				debug: true,
				rules:{
					category: "required",
					Keyword: "required",
				},
				messages:{
				},
				errorElement: "em",
				errorPlacement: function ( error, element ) {
					// Add the `help-block` class to the error element
					error.addClass( "help-block" );

					if ( element.prop( "type" ) === "checkbox" ) {
						error.insertAfter( element.parent( "label" ) );
					} else {
						error.insertAfter( element );
					}
				},
				highlight: function ( element, errorClass, validClass ) {
					$( element ).parents( ".control-group" ).addClass( "has-error" ).removeClass( "has-success" );
				},
				unhighlight: function (element, errorClass, validClass) {
					$( element ).parents( ".control-group" ).addClass( "has-success" ).removeClass( "has-error" );
				},
				submitHandler: function(form){
					$('#result').dataTable().fnClearTable();
					$('#result').dataTable().fnDraw();
					$('#result').dataTable().fnDestroy();

					var category = $('select[name=category]').val();
					var keyword = $('input[name=keyword]').val();

					$('#result').DataTable({
						'ajax'			: '<?= site_url('books/find')?>/'+category+'/'+keyword,
						'deferLoading'	: 10,
						'ordering'		: false,
						'dom'			: '<"top"fl>rt<"bottom"ip><"clear">',
						"language"		: {
							"emptyTable": "<center>No exisisting books.</center>"
						}
					});

					$('.dataTables_filter input').addClass('form-control').attr('placeholder','Search...');
					$('.dataTables_length select').addClass('form-control');
				}
			});
		});

		function loadTable(){
			$('#table').dataTable().fnClearTable();
			$('#table').dataTable().fnDraw();
			$('#table').dataTable().fnDestroy();

			$('#table').DataTable({
				'ajax'			: '<?= site_url('books/read/all')?>',
				'deferLoading'	: 10,
				'dom'			: '<"top"fl>rt<"bottom"ip><"clear">',
				"language"		: {
					"emptyTable": "<center>No books available.</center>"
				}
			});

			$('.dataTables_filter input').addClass('form-control').attr('placeholder','Search...');
			$('.dataTables_length select').addClass('form-control');

			$('#bankForm>.widget-content').slideUp();
			$('#submitForm').hide();
		}

		function edit( ID )
		{
			$('input[name=ID]').val(ID);

			$.ajax({
				type: "POST",
				async: true,
				url: "<?=site_url('books/get');?>",
				data:{ID:ID},
				dataType: 'json',
				cache: false,
				beforeSend: function() 
				{
					$('#loadingModal').modal({
						toggle: "true",
						backdrop: "static",
						keyboard: "false"
					});
				},
				success: function(data)
				{
					$('input[name=title]').val(data[1]);
					$('input[name=author]').val(data[2]);
					$('select[name=genre]').val(data[3]);
					$('select[name=section]').val(data[4]);
					$('#submitForm').show();
					$('#booksForm>.widget-content').slideDown(400).removeClass('hidden');
					scrollToForm();
				},
				error: function(data)
				{
					toastr.options = {
						closeButton: true,
						progressBar: true,
						showMethod: 'slideDown',
						timeOut: 3000
					};
					toastr.error('Please reload the page and try again', 'We encountered a problem!');
				},
				complete: function()
				{
					$('#loadingModal').modal('toggle');
				}
			});
		}

		function lend(ID){
			var result = confirm('Are you sure you want to lend this book?');
			if( result )
			{
				$.ajax({
					type: "POST",
					async: true,
					url: "<?=site_url('books/lend');?>",
					data:{ID:ID},
					dataType: 'json',
					cache: false,
					beforeSend: function() 
					{
						$('#loadingModal').modal({
							toggle: "true",
							backdrop: "static",
							keyboard: "false"
						});
					},
					success: function(data)
					{
						if( data == "Success" )
						{
							toastr.options = {
								closeButton: true,
								progressBar: true,
								showMethod: 'slideDown',
								timeOut: 3000
							};
							toastr.success( "The book has been successfully deleted.","Success");

							loadTable();
						}
						else
						{
							toastr.options = {
								closeButton: true,
								progressBar: true,
								showMethod: 'slideDown',
								timeOut: 3000
							};
							toastr.error('Please reload the page and try again', 'We encountered a problem!');
						}
					},
					error: function(data)
					{
						toastr.options = {
							closeButton: true,
							progressBar: true,
							showMethod: 'slideDown',
							timeOut: 3000
						};
						toastr.error('Please reload the page and try again', 'We encountered a problem!');
					},
					complete: function()
					{
						$('#loadingModal').modal('toggle');
					}
				});
			}
		}

		function returnBook(ID){
			var result = confirm('Are you sure you want to lend this book?');
			if( result )
			{
				$.ajax({
					type: "POST",
					async: true,
					url: "<?=site_url('books/return');?>",
					data:{ID:ID},
					dataType: 'json',
					cache: false,
					beforeSend: function() 
					{
						$('#loadingModal').modal({
							toggle: "true",
							backdrop: "static",
							keyboard: "false"
						});
					},
					success: function(data)
					{
						if( data == "Success" )
						{
							toastr.options = {
								closeButton: true,
								progressBar: true,
								showMethod: 'slideDown',
								timeOut: 3000
							};
							toastr.success( "The book has been successfully deleted.","Success");

							loadTable();
						}
						else
						{
							toastr.options = {
								closeButton: true,
								progressBar: true,
								showMethod: 'slideDown',
								timeOut: 3000
							};
							toastr.error('Please reload the page and try again', 'We encountered a problem!');
						}
					},
					error: function(data)
					{
						toastr.options = {
							closeButton: true,
							progressBar: true,
							showMethod: 'slideDown',
							timeOut: 3000
						};
						toastr.error('Please reload the page and try again', 'We encountered a problem!');
					},
					complete: function()
					{
						$('#loadingModal').modal('toggle');
					}
				});
			}
		}

		function remove( ID )
		{
			var result = confirm('Are you sure you want to delete this book?');
			if( result )
			{
				$.ajax({
					type: "POST",
					async: true,
					url: "<?=site_url('books/delete');?>",
					data:{ID:ID},
					dataType: 'json',
					cache: false,
					beforeSend: function() 
					{
						$('#loadingModal').modal({
							toggle: "true",
							backdrop: "static",
							keyboard: "false"
						});
					},
					success: function(data)
					{
						if( data == "Success" )
						{
							toastr.options = {
								closeButton: true,
								progressBar: true,
								showMethod: 'slideDown',
								timeOut: 3000
							};
							toastr.success( "The book has been successfully deleted.","Success");

							loadTable();
						}
						else
						{
							toastr.options = {
								closeButton: true,
								progressBar: true,
								showMethod: 'slideDown',
								timeOut: 3000
							};
							toastr.error('Please reload the page and try again', 'We encountered a problem!');
						}
					},
					error: function(data)
					{
						toastr.options = {
							closeButton: true,
							progressBar: true,
							showMethod: 'slideDown',
							timeOut: 3000
						};
						toastr.error('Please reload the page and try again', 'We encountered a problem!');
					},
					complete: function()
					{
						$('#loadingModal').modal('toggle');
					}
				});
			}
		}

		function clearForm(){
			$('#submitForm')[0].reset();
			$('input[name=ID').val('');
		}

		function scrollToForm(){
			$('html, body').animate({
				scrollTop: $("#booksForm").offset().top
			}, 400);
		}

		function scrollToTable(){
			$('html, body').animate({
				scrollTop: $("#booksTable").offset().top
			}, 400);
		}
	</script>