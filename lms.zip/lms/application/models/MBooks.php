<?php
defined ('BASEPATH') OR exit ('No direct script access allowed');

class MBooks extends CI_Model
{
	public function readAllBooks()
	{
		$result = array();

		$this->db->select('*')
				->from('books');

		$query = $this->db->get();

		if( $query->num_rows() > 0 )
		{
			foreach( $query->result() as $row )
			{
				if( $row->Status == "Available" )
				{
					$action = "<center><a title='Edit' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:edit(".$row->ID.")'><i class='icon-edit'></i><span></span></a>&nbsp;<a title='Lend this book' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:lend(".$row->ID.")'><i class='icon-upload'></i> <span></span> </a>&nbsp;<a title='Delete' class='btn btn-danger btn-small' data-toggle='tooltip' data-placement='top' href='javascript:remove(".$row->ID.")'><i class='icon-trash'></i><span> </span></a></center>";
					$status = "<center><button class='btn btn-success btn-small'>".$row->Status."</button></center>";
				}
				else
				{	
					$action = "<center><a title='Edit' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:edit(".$row->ID.")'><i class='icon-edit'></i><span></span></a>&nbsp;<a title='Book returned?' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:returnBook(".$row->ID.")'><i class='icon-download'></i> <span></span> </a>&nbsp;<a title='Delete' class='btn btn-danger btn-small' data-toggle='tooltip' data-placement='top' href='javascript:remove(".$row->ID.")'><i class='icon-trash'></i><span> </span></a></center>";
					$status = "<center><button class='btn btn-danger btn-small'>".$row->Status."</button></center>";
				}

				$result[] = array(
					"<center>".$row->Title."</center>",
					"<center>".$row->Author."</center>",
					"<center>".$row->Genre."</center>",
					"<center>".$row->Section."</center>",
					$status,
					$action
				);
			}
		}

		return $result;
	}

	public function searchBooksBy( $category = null, $keyword = null )
	{
		$result = array();

		$this->db->select('*')
				->from('books')
				->where('Status','Available');

		if( $category != null && $keyword != null )
		{
			$this->db->like($category,$keyword);
		}

		$query = $this->db->get();

		if( $query->num_rows() > 0 )
		{
			foreach( $query->result() as $row )
			{
				if( $row->Status == "Available" )
				{
					$action = "<center><a title='Edit' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:edit(".$row->ID.")'><i class='icon-edit'></i><span></span></a>&nbsp;<a title='Lend this book' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:lend(".$row->ID.")'><i class='icon-upload'></i> <span></span> </a>&nbsp;<a title='Delete' class='btn btn-danger btn-small' data-toggle='tooltip' data-placement='top' href='javascript:remove(".$row->ID.")'><i class='icon-trash'></i><span> </span></a></center>";
					$status = "<center><button class='btn btn-success btn-small'>".$row->Status."</button></center>";
				}
				else
				{	
					$action = "<center><a title='Edit' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:edit(".$row->ID.")'><i class='icon-edit'></i><span></span></a>&nbsp;<a title='Book returned?' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:returnBook(".$row->ID.")'><i class='icon-download'></i> <span></span> </a>&nbsp;<a title='Delete' class='btn btn-danger btn-small' data-toggle='tooltip' data-placement='top' href='javascript:remove(".$row->ID.")'><i class='icon-trash'></i><span> </span></a></center>";
					$status = "<center><button class='btn btn-danger btn-small'>".$row->Status."</button></center>";
				}

				$result[] = array(
					"<center>".$row->Title."</center>",
					"<center>".$row->Author."</center>",
					"<center>".$row->Genre."</center>",
					"<center>".$row->Section."</center>",
					$status,
					$action
				);
			}
		}

		return $result;
	}

	public function ifBookExists( $data )
	{
		$this->db->select('*')
				->from('books')
				->where('Title', $data['Title'])
				->where('Author', $data['Author']);

		if( ! empty( $data['ID']) )
			$this->db->where('ID !=', $data['ID']);

		$query = $this->db->get();

		if ( $query->num_rows() > 0 )
			return true;
		else
			return false;
	}

	public function add( $data )
	{
		$this->db->trans_start();
		
		$this->db->insert('books', $data);
		
		$this->db->trans_complete();

		if ( $this->db->trans_status() )
			return "Success";
		else
			return "Error";
	}

	public function getSelected( $ID )
	{
		$result = array();

		$query = $this->db->select('*')
						->from('books')
						->where('ID',$ID)
						->get();

		if ( $query->num_rows() > 0 )
		{
			$row = $query->row();

			$result = array(
				$row->ID,
				$row->Title,
				$row->Author,
				$row->Genre,
				$row->Section
			);
		}

		return $result;
	}

	public function update( $data )
	{
		$this->db->trans_start();
		
		$this->db->where('ID',$data['ID']);
		$this->db->update('books', $data);
		
		$this->db->trans_complete();

		if ( $this->db->trans_status() )
			return "Success";
		else
			return "Error";
	}

	public function lend( $ID )
	{
		$this->db->trans_start();

		$this->db->where('ID',$ID);
		$this->db->update('books', array( 'ID' => $ID, 'Status' => 'Borrowed' ) );

		$this->db->trans_complete();

		if ( $this->db->trans_status() )
			return "Success";
		else
			return "Error";
	}

	public function delete( $ID )
	{
		$this->db->trans_start();

		$this->db->where('ID',$ID);
		$this->db->delete('books');

		$this->db->trans_complete();

		if ( $this->db->trans_status() )
			return "Success";
		else
			return "Error";
	}

	public function readAllBorrowedBooks()
	{
		$result = array();

		$this->db->select('*')
				->from('books')
				->where('Status','Borrowed');

		$query = $this->db->get();

		if( $query->num_rows() > 0 )
		{
			foreach( $query->result() as $row )
			{
				$action = "<center><a title='Book returned?' class='btn btn-primary btn-small' data-toggle='tooltip' data-placement='top' href='javascript:returnBook(".$row->ID.")'><i class='icon-download'></i> <span></span> </a></center>";

				$result[] = array(
					"<center>".$row->Title."</center>",
					"<center>".$row->Author."</center>",
					"<center>".$row->Genre."</center>",
					"<center>".$row->Section."</center>",
					"<center>".$row->Status."</center>",
					$action
				);
			}
		}

		return $result;
	}

	public function returnBook( $ID )
	{
		$this->db->trans_start();

		$this->db->where('ID',$ID);
		$this->db->update('books', array( 'ID' => $ID, 'Status' => 'Available' ) );

		$this->db->trans_complete();

		if ( $this->db->trans_status() )
			return "Success";
		else
			return "Error";
	}
}